package common;

public class Page {
	/**
	 * 当前页
	 */
	private int currentPage;
	/**
	 * 每页有多少条数据
	 */
	private int columnPage;
	//总共有多少数据
	private int columnCount;
	//一共有多少页
	private int pageCount;
	
	
	public Page() {
		currentPage = 1;
		columnPage = 6;
		columnCount = 0;
		pageCount = 0;
	}
	
	public Page(int currentPage, int columnPage, int columnCount, int pageCount) {
		this();
		this.currentPage = currentPage;
		this.columnPage = columnPage;
		this.columnCount = columnCount;
		this.pageCount = pageCount;
	}

	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getColumnPage() {
		return columnPage;
	}
	public void setColumnPage(int columnPage) {
		this.columnPage = columnPage;
	}
	public int getColumnCount() {
		return columnCount;
	}
	public void setColumnCount(int columnCount) {
		this.columnCount = columnCount;
		int i = (this.columnCount % columnPage == 0) ? 0 : 1;
		this.pageCount = this.columnCount / columnPage + i;
	}
	public int getPageCount() {
		return pageCount;
	}
}
