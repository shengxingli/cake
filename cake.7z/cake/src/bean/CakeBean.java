package bean;

public class CakeBean {

	private int cakeId;
	private String cakeName;
	private int cakeSize;
	private double cakePrice;
	private String cakeType;
	private String cakeImage;
	
	public int getCakeId() {
		return cakeId;
	}
	public void setCakeId(int cakeId) {
		this.cakeId = cakeId;
	}
	public String getCakeName() {
		return cakeName;
	}
	public void setCakeName(String cakeName) {
		this.cakeName = cakeName;
	}
	public int getCakeSize() {
		return cakeSize;
	}
	public void setCakeSize(int cakeSize) {
		this.cakeSize = cakeSize;
	}
	public double getCakePrice() {
		return cakePrice;
	}
	public void setCakePrice(double cakePrice) {
		this.cakePrice = cakePrice;
	}
	public String getCakeType() {
		return cakeType;
	}
	public void setCakeType(String cakeType) {
		this.cakeType = cakeType;
	}
	public String getCakeImage() {
		return cakeImage;
	}
	public void setCakeImage(String cakeImage) {
		this.cakeImage = cakeImage;
	}
	
	
	
	
	
	
	
}
