package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter("/LoginFilter")
public class LoginFilter implements Filter {

	/**
	 * Default constructor.
	 */
	public LoginFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		String path = req.getRequestURL().toString();
		if (path.contains("shoppingCart.jsp")) {
				HttpSession session = req.getSession();
				if (session.getAttribute("userName") == null) {
					System.out.print("不能访问");
					String loginmsg = "请先登录";
					req.setAttribute("loginmsg", loginmsg);
					req.getRequestDispatcher("index.jsp").forward(req, resp);
				} else {
					req.getRequestDispatcher("shoppongCart.jsp").forward(req, resp);
				}
		} else if (path.contains("ShoppingCartServlet")) {
			HttpSession session = req.getSession();
			if (session.getAttribute("userName") == null) {
				System.out.print("不能访问");
				String loginMsg = "请先登录";
				req.setAttribute("loginMsg", loginMsg);
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				chain.doFilter(request, response);
			}
		} else if(path.contains("OrderServlet")) {
			HttpSession session = req.getSession();
			if (session.getAttribute("userName") == null) {
				System.out.print("不能访问");
				String loginMsg = "请先登录";
				req.setAttribute("loginMsg", loginMsg);
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				chain.doFilter(request, response);
			}
		} else if(path.contains("PutOrderServlet")) {
			HttpSession session = req.getSession();
			if (session.getAttribute("userName") == null) {
				String loginMsg = "请先登录";
				req.setAttribute("loginMsg", loginMsg);
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				chain.doFilter(request, response);
			}
		} else if(path.contains("fill_order.jsp")) {
			HttpSession session = req.getSession();
			if (session.getAttribute("userName") == null) {
				String loginMsg = "请先登录";
				req.setAttribute("loginMsg", loginMsg);
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				chain.doFilter(request, response);
			}
		} else if(path.contains("order.jsp")) {
			HttpSession session = req.getSession();
			if (session.getAttribute("userName") == null) {
				String loginMsg = "请先登录";
				req.setAttribute("loginMsg", loginMsg);
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				chain.doFilter(request, response);
			}
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
