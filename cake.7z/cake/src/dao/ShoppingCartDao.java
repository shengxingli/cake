package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import bean.ShoppingCartBean;

public class ShoppingCartDao {

	/**
	 * 判断购物车是否存在 如果存在返回1，不存在再返回购物车id
	 * 
	 * @throws SQLException
	 */
	public int exist(int userId) throws SQLException {
		int shoppingCartId = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shoppingcart_id from shoppingcart where user_id=?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, userId);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			shoppingCartId = rs.getInt(1);
		}
		System.out.print("\n"+shoppingCartId+"查询到的购物车id");
		if (shoppingCartId == 0) {
			return 0;
		} else {
			return shoppingCartId;
		}
	}

	/*
	 * 根据用户名字查询用户的id
	 */
	
	public int getUserIdByUserName (String userName) {
		int userId = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_id from user where user_name=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				userId = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print(userName+userId+"查询到的用户id是");
		return userId;
	}

	/*
	 * 根据用户名字查询购物车
	 */
	public ShoppingCartBean getShoppingCartByUserName(String userName) {
		try {
			int userId = getUserIdByUserName(userName);
			if (exist(userId) == 0) {
				ShoppingCartBean shoppingCartBean = new ShoppingCartBean();
				Connection conn = Database.getConnection();
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				String sql = "insert into shoppingCart(user_id)values(?)";
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.setInt(1, userId);
				pstmt.executeUpdate();
				rs = pstmt.getGeneratedKeys();
				while (rs.next()) {
					shoppingCartBean.setShoppingCartId(rs.getInt(1));
				}
				shoppingCartBean.setUserId(userId);
				return shoppingCartBean;
			} else {
				ShoppingCartBean shoppingCartBean = new ShoppingCartBean();
				shoppingCartBean.setShoppingCartId(exist(userId));
				shoppingCartBean.setUserId(userId);
				return shoppingCartBean;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

}
