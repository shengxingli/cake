package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import bean.CakeBean;
import bean.OrderDetailBean;
import bean.ShoppingCartDetailBean;

public class OrderDetailDao {

	/*
	 * 添加订单
	 */
	public void add(ShoppingCartDetailBean shoppingCartDetail) {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into order_detail(order_id,cake_id,cake_count) values(?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, orderId);
			pstmt.setInt(2, shoppingCartDetailBean.getCake().getCakeId());
			pstmt.setInt(3, shoppingCartDetailBean.getCount());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sql = "delete from shoppingcart_detail where shoppingcart_id=?";
		try {
			PreparedStatement pstmt = null;
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * 根据订单id查询订单
	 */
	public List<OrderDetailBean> getOrderDetailByOrderId(int orderId) {
		List<OrderDetailBean> list = new ArrayList<OrderDetailBean>();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select order_detail_id,cake_id,cake_count from order_detail where order_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				OrderDetailBean detail = new OrderDetailBean();
				detail.setOrderDetailId(rs.getInt(1));
				detail.setOrderId(orderId);
				CakeBean cake = new CakeDao().getCakeById(rs.getInt(2));
				detail.setCake(cake);
				detail.setCount(rs.getInt(3));
				list.add(detail);
			}
			return list;
		} catch (SQLException e) {

		}
		return list;
	}
}
