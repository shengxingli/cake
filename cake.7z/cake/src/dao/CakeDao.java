package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import bean.CakeBean;

public class CakeDao {

	/*
	 * 通过id获取蛋糕信息
	 */

	public CakeBean getCakeById(int cakeId) {
		CakeBean cakeBean = new CakeBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from cake where cake_id=?";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, cakeId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cakeBean.setCakeId(rs.getInt(1));
				cakeBean.setCakeName(rs.getString(2));
				cakeBean.setCakeSize(rs.getInt(3));
				cakeBean.setCakePrice(rs.getDouble(4));
				cakeBean.setCakeType(rs.getString(5));
				cakeBean.setCakeImage(rs.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cakeBean;
	}

	/*
	 * 根据类别获取蛋糕列表
	 */
	public List<CakeBean> getCakeListByType(String type) {
		List<CakeBean> list = new ArrayList<CakeBean>();
		if (type.equals("all")) {
			Connection conn = Database.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select * from cake";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					CakeBean cakeBean = new CakeBean();
					cakeBean.setCakeId(rs.getInt(1));
					cakeBean.setCakeName(rs.getString(2));
					cakeBean.setCakeSize(rs.getInt(3));
					cakeBean.setCakePrice(rs.getDouble(4));
					cakeBean.setCakeType(rs.getString(5));
					cakeBean.setCakeImage(rs.getString(6));
					list.add(cakeBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Connection conn = Database.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select * from cake where cake_type=?";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, type);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					CakeBean cakeBean = new CakeBean();
					cakeBean.setCakeId(rs.getInt(1));
					cakeBean.setCakeName(rs.getString(2));
					cakeBean.setCakeSize(rs.getInt(3));
					cakeBean.setCakePrice(rs.getDouble(4));
					cakeBean.setCakeType(rs.getString(5));
					cakeBean.setCakeImage(rs.getString(6));
					list.add(cakeBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	/*
	 * 根据尺寸获取蛋糕列表
	 */
	public List<CakeBean> getCakeListBySize(int size) {
		List<CakeBean> list = new ArrayList<CakeBean>();
			Connection conn = Database.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select * from cake where cake_size=?";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.setInt(1,size);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					CakeBean cakeBean = new CakeBean();
					cakeBean.setCakeId(rs.getInt(1));
					cakeBean.setCakeName(rs.getString(2));
					cakeBean.setCakeSize(rs.getInt(3));
					cakeBean.setCakePrice(rs.getDouble(4));
					cakeBean.setCakeType(rs.getString(5));
					cakeBean.setCakeImage(rs.getString(6));
					list.add(cakeBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return list;
	}
	

	/*
	 * 通过名字获取蛋糕ID
	 */

	public int getCakeByName(String cakeName) {
		int cakeId = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select cake_id from cake where cake_name=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cakeName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cakeId = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cakeId;
	}
}
