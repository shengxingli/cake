package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import com.mysql.jdbc.Statement;

import bean.CakeBean;
import bean.ShoppingCartBean;
import bean.ShoppingCartDetailBean;

public class ShoppingCartDetailDao {

	/*
	 * 添加购物车
	 */
	public ShoppingCartDetailBean add(int shoppingCartId,int cakeId,int count){
		ShoppingCartDetailBean shoppingCartDetail = new ShoppingCartDetailBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into shoppingcart_detail(shoppingcart_id,cake_id,count,add_time) values(?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(2, cakeId);
			pstmt.setInt(1, shoppingCartId);
			pstmt.setInt(3, count);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
			System.out.println(df.format(new Date()));
			pstmt.setString(4, df.format(new Date()));
			pstmt.executeUpdate();
			
			rs = pstmt.getGeneratedKeys();
			while(rs.next()) {
				shoppingCartDetail.setShoppingCartDetailId(rs.getInt(1));
			}
			CakeBean cake = new CakeDao().getCakeById(cakeId);
			shoppingCartDetail.setCake(cake);
			
			
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shoppingCartDetail;
	}
	/*
	 * 根据用户id查询购物车
	 */
	public List<ShoppingCartDetailBean> getShoppingCartDetailByShoppingCartId(int shoppingCartId) {
		List<ShoppingCartDetailBean> list = new ArrayList<ShoppingCartDetailBean>();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shoppingcart_detail_id,cake_id,count,add_time from shoppingcart_detail where shoppingcart_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ShoppingCartDetailBean detail = new ShoppingCartDetailBean();
				detail.setShoppingCartDetailId(rs.getInt(1));
				CakeBean cake = new CakeDao().getCakeById(rs.getInt(2));
				System.out.print(rs.getInt(2)+"这是蛋糕的id");
				detail.setCake(cake);
				detail.setCount(rs.getInt(3));
				detail.setAddTime(rs.getDate(4));
				list.add(detail);
			}
			return list;
		}catch(SQLException e) {
			
		}
		return list;
	}
	
	/*
	 * 删除购物车的项目
	 */
	
	public void delete(int shoppingCartDetailId){
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "delete from shoppingcart_detail where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/*
	 * 减少购物车中某商品的数量
	 */
	public void less(int shoppingCartDetailId){
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update shoppingcart_detail set count=count-1 where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/*
	 * 增加购物车中某商品的数量
	 */
	public void addCakeNum(int shoppingCartDetailId){
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update shoppingcart_detail set count=count+1 where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
