package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import bean.ShoppingCartBean;
import bean.UserBean;

public class UserDao {
	
	/*
	 * 
	 */
	public void addUser(UserBean userBean) throws SQLException {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "insert into user(user_name,user_password,user_email,user_tel,user_address) values(?,?,?,?,?)";
		pstmt = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		pstmt.setString(1, userBean.getUserName());
		pstmt.setString(2, userBean.getUserPassword());
		pstmt.setString(3, userBean.getUserEmail());
		pstmt.setString(4, userBean.getUserTel());
		pstmt.setString(5, userBean.getUserAddress());
		pstmt.executeUpdate();
	}
	public boolean exist(String name) throws SQLException {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_name from user";
		ResultSet rs = null;
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			if(name.equals(rs.getString(1)))
				return true;
		}
		return false;
	}
	
	public UserBean getUserByUserName (String userName) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_id,user_password,user_email,user_tel,user_address from user where user_name=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				user.setUserId(rs.getInt(1));
				user.setUserName(userName);
				user.setUserPassword(rs.getString(2));
				user.setUserEmail(rs.getString(3));
				user.setUserTel(rs.getString(4));
				user.setUserAddress(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	/*
	 * 通过邮箱找到密码
	 */
	public String findPwdByEmail(String email) {
		String password = "";
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_password from user where user_email=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				password = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return password;
	}
	
}
