package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import bean.OrderBean;
import bean.ShoppingCartBean;
import bean.ShoppingCartDetailBean;

public class OrderDao {

	/*
	 * 根据用户名字查询用户的id
	 */
	private int getUserIdByUserName(String userName) {
		int userId = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_id from user where user_name=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				userId = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print(userName + userId + "查询到的用户id是");
		return userId;
	}

	/*
	 * 根据用户名字查询订单
	 */
	@SuppressWarnings("null")
	public List<OrderBean> getOrderListByUserName(String userName) {
		List<OrderBean> orderList = new ArrayList<OrderBean>();
		OrderBean orderBean = null;
		try {
			int userId = getUserIdByUserName(userName);
			System.out.println("userId="+userId);
			orderBean = new OrderBean();
			Connection conn = Database.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select order_id,order_state,order_time,order_price from `order` where user_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				orderBean = new OrderBean();
				orderBean.setOrderId(rs.getInt(1));
				orderBean.setOrderState(rs.getString(2));
				orderBean.setOrderTime(rs.getDate(3));
				orderBean.setPrice(rs.getDouble(4));
				orderBean.setUserId(userId);
				orderList.add(orderBean);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return orderList;
	}

	/*
	 * 提交订单
	 */
	public void add(String userName, List<ShoppingCartDetailBean> list) {
		System.out.println("现在要新建order表");
		double price = 0;
		int orderId = 0;
		ShoppingCartDao shoppingCartDao = new ShoppingCartDao();
		int userId = shoppingCartDao.getUserIdByUserName(userName);
		for (ShoppingCartDetailBean bean : list) {
			price = price + bean.getCount() * bean.getCake().getCakePrice();
		}
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into `order`(user_id,order_state,order_price,order_time) values(?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, userId);
			pstmt.setDouble(3, price);
			pstmt.setString(2, "已支付");
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			pstmt.setString(4, df.format(new Date()));
			pstmt.executeUpdate();
			
			rs = pstmt.getGeneratedKeys();
			while (rs.next()) {
				orderId = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int shoppingCartId = shoppingCartDao.getShoppingCartByUserName(userName).getShoppingCartId();
		new OrderDetailDao().add(list, orderId, shoppingCartId);
	}
}
