package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import bean.CakeBean;
import bean.ShoppingCartDetailBean;

public class LoginDao {

	public boolean presence(String name,String password) throws SQLException {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_password from user where user_name=?";
		ResultSet rs = null;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		rs = pstmt.executeQuery();
		String user_password = "";
		while(rs.next()) {
			
			user_password = rs.getString(1);
					
		}
		System.out.print(user_password);
		if(password.equals(user_password)) {
			return true;
		}else {
			return false;
		}
	}
	
}
