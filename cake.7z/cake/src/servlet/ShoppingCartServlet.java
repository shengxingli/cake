package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ShoppingCartBean;
import bean.ShoppingCartDetailBean;
import dao.ShoppingCartDao;
import dao.ShoppingCartDetailDao;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShoppingCartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String remark = request.getParameter("remark");
		if (remark.equals("add")) {
			add(request, response);
		} else if (remark.equals("select")) {
			select(request, response);
		} else if (remark.equals("delete")) {
			delete(request, response);
		}

	}

	protected void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("count") == null || Integer.parseInt(request.getParameter("count")) == 1) {
			int shoppingCartDetailId = Integer.parseInt(request.getParameter("shoppingCartDetailId"));
			new ShoppingCartDetailDao().delete(shoppingCartDetailId);
			request.getRequestDispatcher("ShoppingCartServlet?remark=select").forward(request, response);
		} else {
			int shoppingCartDetailId = Integer.parseInt(request.getParameter("shoppingCartDetailId"));
			new ShoppingCartDetailDao().less(shoppingCartDetailId);
			request.getRequestDispatcher("ShoppingCartServlet?remark=select").forward(request, response);
		}

	}

	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		if (request.getParameter("cakeId") == null) {
			int shoppingCartDetailId = Integer.parseInt(request.getParameter("shoppingCartDetailId"));
			new ShoppingCartDetailDao().addCakeNum(shoppingCartDetailId);
			request.getRequestDispatcher("ShoppingCartServlet?remark=select").forward(request, response);
		} else {
			HttpSession session = request.getSession();
			String userName = (String) session.getAttribute("userName");
			int cakeId = Integer.parseInt(request.getParameter("cakeId"));
			int count = Integer.parseInt(request.getParameter("count"));
			System.out.print("这是你购买蛋糕的数量:" + count + "\n");
			ShoppingCartDao shoppingCartDao = new ShoppingCartDao();
			// 从数据库中查询用户的购物车
			ShoppingCartBean shoppingCart = shoppingCartDao.getShoppingCartByUserName(userName);

			ShoppingCartDetailDao shoppingCartDetailDao = new ShoppingCartDetailDao();
			ShoppingCartDetailBean shoppingCartDetail = null;
			shoppingCartDetail = shoppingCartDetailDao.add(shoppingCart.getShoppingCartId(), cakeId, count);

			request.getRequestDispatcher("ProductsServlet?type=all").forward(request, response);
		}
	}

	protected void select(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName");
		System.out.print("\n购物车的用户名是：" + userName + "\n");
		ShoppingCartDao shoppingCartDao = new ShoppingCartDao();
		ShoppingCartBean shoppingCart = shoppingCartDao.getShoppingCartByUserName(userName);

		ShoppingCartDetailDao shoppingCartDetailDao = new ShoppingCartDetailDao();
		List<ShoppingCartDetailBean> detailList = shoppingCartDetailDao
				.getShoppingCartDetailByShoppingCartId(shoppingCart.getShoppingCartId());
		request.setAttribute("detailList", detailList);
		request.getRequestDispatcher("shoppingCart.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
