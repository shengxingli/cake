package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CakeBean;
import dao.CakeDao;

/**
 * Servlet implementation class CakeServlet
 */
@WebServlet("/CakeServlet")
public class CakeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CakeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("size") != null) {
			List<CakeBean> list = new ArrayList<CakeBean>();
			list = new CakeDao().getCakeListBySize(Integer.parseInt(request.getParameter("size")));
			request.setAttribute("cakeList", list);
			request.getRequestDispatcher("ProductsServlet").forward(request, response);
		}else if(request.getParameter("cakeId") != null) {
			int cakeId = Integer.parseInt(request.getParameter("cakeId"));
			CakeBean cakeBean = new CakeBean();
			cakeBean = new CakeDao().getCakeById(cakeId);
			List<CakeBean> cakeList = new ArrayList<CakeBean>();
			cakeList = new CakeDao().getCakeListByType(cakeBean.getCakeType());
			request.setAttribute("cakeList", cakeList);
			request.setAttribute("cakeBean", cakeBean);
			request.getRequestDispatcher("single.jsp").forward(request, response);
		}else if(request.getParameter("cakeName") != null) {
			int cakeId = new CakeDao().getCakeByName(request.getParameter("cakeName"));
			request.getRequestDispatcher("CakeServlet?cakeId="+cakeId).forward(request, response);
		}else {
			List<CakeBean> list = new ArrayList<CakeBean>();
			list = new CakeDao().getCakeListByType(request.getParameter("type"));
			request.setAttribute("cakeList", list);
			request.getRequestDispatcher("ProductsServlet").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
