package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LoginDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("userName") == "" || request.getParameter("userPassword") == "") {
			String loginMsg = "用户名或密码为空";
			request.setAttribute("loginMsg", loginMsg);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		} else {
			String name = request.getParameter("userName");
			String password = request.getParameter("userPassword");
			System.out.println("用户名和密码："+name+password);
			try {
				if (new LoginDao().presence(name, password) == true) {
					System.out.println("用户名和密码："+name+password);
					HttpSession session = request.getSession();
					session.setAttribute("userName", name);
					request.getRequestDispatcher("ProductsServlet?type=all").forward(request, response);
				} else {
					String loginMsg = "用户名或密码错误";
					request.setAttribute("loginMsg", loginMsg);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
