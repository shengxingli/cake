package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.OrderBean;
import bean.OrderDetailBean;
import bean.ShoppingCartBean;
import bean.ShoppingCartDetailBean;
import bean.UserBean;
import dao.OrderDao;
import dao.OrderDetailDao;
import dao.ShoppingCartDao;
import dao.ShoppingCartDetailDao;
import dao.UserDao;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String remark = request.getParameter("remark");
		if (remark.equals("add")) {
			add(request, response);
		} else if (remark.equals("select")) {
			select(request, response);
		}
	}

	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			HttpSession session = request.getSession();
			String userName = (String) session.getAttribute("userName");
			ShoppingCartDetailDao shoppingCartDetailDao = new ShoppingCartDetailDao();
			int shoppingCartId = new ShoppingCartDao().getShoppingCartByUserName(userName).getShoppingCartId();
			List<ShoppingCartDetailBean> list = shoppingCartDetailDao.getShoppingCartDetailByShoppingCartId(
					shoppingCartId);
			new OrderDao().add(userName,list);
			request.getRequestDispatcher("ShoppingCartServlet?remark=select").forward(request, response);
	}

	protected void select(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName");
		OrderDao orderDao = new OrderDao();
		List<OrderBean> orderList = orderDao.getOrderListByUserName(userName);
		request.setAttribute("orderList", orderList);
		request.getRequestDispatcher("order.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
