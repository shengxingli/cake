package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CakeBean;
import common.Page;
import dao.CakeDao;

/**
 * Servlet implementation class ProductsServlet
 */
@WebServlet("/ProductsServlet")
public class ProductsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		CakeDao cakeDao = new CakeDao();
		String currentPageStr = request.getParameter("currentPage");
		String type = request.getParameter("type");
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}
		HttpSession session = request.getSession();
		List<CakeBean> cakeList = null;
		if (request.getAttribute("cakeList") == null) {
			if (session.getAttribute("cakeList") == null) {
				cakeList = cakeDao.getCakeListByType(type);
			} else {
				cakeList = (List<CakeBean>) session.getAttribute("cakeList");
			}
		} else {
			cakeList = (List<CakeBean>) request.getAttribute("cakeList");
		}
		session.setAttribute("cakeList", cakeList);
		Page page = new Page();
		page.setColumnCount(cakeList.size());
		page.setCurrentPage(currentPage);
		List<CakeBean> subCakeList = new ArrayList<CakeBean>();
		int fromIndex = (currentPage - 1) * page.getColumnPage();
		int yuShu = page.getColumnCount() % page.getColumnPage();
		int toIndex = (currentPage < page.getPageCount()) ? (fromIndex + page.getColumnPage()) : (fromIndex + yuShu);

		subCakeList = cakeList.subList(fromIndex, toIndex);
		request.setAttribute("type", type);
		request.setAttribute("subCakeList", subCakeList);
		request.setAttribute("page", page);
		request.getRequestDispatcher("products.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
