package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ShoppingCartDetailBean;
import bean.UserBean;
import dao.ShoppingCartDao;
import dao.ShoppingCartDetailDao;
import dao.UserDao;

/**
 * Servlet implementation class PutOrderServlet
 */
@WebServlet("/PutOrderServlet")
public class PutOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PutOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName");
		ShoppingCartDao shoppingCart = new ShoppingCartDao();
		int shoppingCartId = shoppingCart.getShoppingCartByUserName(userName).getShoppingCartId();
		List<ShoppingCartDetailBean> list = new ShoppingCartDetailDao().getShoppingCartDetailByShoppingCartId(
				shoppingCartId);
		System.out.println("获取到的用户名字是："+userName);
		UserBean user = new UserDao().getUserByUserName(userName);
		request.setAttribute("DetailList", list);
		request.setAttribute("user", user);
		request.getRequestDispatcher("fill_order.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
